// *****************************************************************************
//
// This file is part of a MASA library or program.
// Refer to the included end-user license agreement for restrictions.
//
// Copyright (c) 2007 Math�matiques Appliqu�es SA (MASA)
//
// *****************************************************************************

#include "3a_test_pch.h"
#include "3a/DispatchedFunctionHelper.h"
#include "3a/Attributes.h"
#include "3a/IdentifierValue.h"

// -----------------------------------------------------------------------------
// Name: Facade_TestConcept
// Created: AGE 2004-12-15
// -----------------------------------------------------------------------------
BOOST_AUTO_TEST_CASE( Facade_TestConcept )
{
    const std::string simpleInput = 
        "<indicator>"
            "<model-value type='operational-state' name='opstate'/>"
            "<reduction type='mean' name='opstate-mean' input='opstate'/>"
            "<result type='plot' input='opstate-mean'/>"
        "</indicator>";

    const std::string complexInputMin = 
        "<indicator>"
            "<model-value type='operational-state' name='opstate'/>"
            "<model-value type='position' name='position'/>"
            "<transform type='constant' value-type='float' value='2000' name='radius'/>"
            "<reduction type='select' name='my-position' input='position' key='12'/>"
            "<transform type='circle' center='my-position' radius='radius' name='my-circle'/>"
            "<transform type='contains' zone='circle' position='position' name='is-inside'/>"
            "<transform type='test' value='opstate' condition='is-inside' name='opstate-inside'/>"
            "<reduction type='add' input='opstate-inside' name='sum-opstate-inside'/>"
            "<result type='plot' input='sum-opstate-inside'/>"
        "</indicator>";
}


